//
//  ViewController.swift
//  AboutMeBasic1
//
//  Created by Vittorio Bonomi on 4/18/20.
//  Copyright © 2020 Vittorio Bonomi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    func setUpAboutMe(){
        
        nameLabel.text = "Vittorio Bonomi"
        
        titleLabel.text = "HVAC Profesional"
        
        ageLabel.text = "Age: 36"
        
        imageView.image = UIImage(named: "VittorioBonomiProfile")
        
        bioLabel.text = "We distribute in North America, 100% made in Italy, top quality, manual ball and check valves, motorized valves for HVAC, in brass and steel. Actuator, BTU meter, thermal metering module, leaking detection system, water management systems."
    }
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var bioLabel: UILabel!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpAboutMe()
        // Do any additional setup after loading the view.
    }


}

